import React from 'react'

export default function Static() {
  return (
    <div>服务条框</div>
  )
}
