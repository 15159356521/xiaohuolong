import React from 'react'

export default function Invitation() {
  return (
    <div>Invitation</div>
  )
}
