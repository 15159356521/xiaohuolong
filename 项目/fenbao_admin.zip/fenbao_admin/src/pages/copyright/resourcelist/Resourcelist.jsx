import React from 'react'

export default function Resourcelist() {
  return (
    <div>Resourcelist</div>
  )
}
