import IndexRouter from "./router/IndexRouter"
import React from "react"
import './App.css'

function App(){

  return  <IndexRouter></IndexRouter>
 


  

}
export default App
