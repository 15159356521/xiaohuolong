const getToken = () => {
  return window.localStorage.getItem("token");
};
export { getToken };
