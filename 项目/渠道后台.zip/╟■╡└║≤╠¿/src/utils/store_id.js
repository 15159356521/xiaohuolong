const getstore_id = () => {
  return localStorage.getItem("class");
};
export { getstore_id };
